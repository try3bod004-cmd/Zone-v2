package com.zone.vr;

interface IShell {
    void destroy() = 16777114;
    String exec(String cmd) = 1;
}
