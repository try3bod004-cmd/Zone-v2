package com.zone.vr

/** Runs inside the Shizuku process with shell (adb) privileges. */
class ShellService : IShell.Stub() {
    override fun destroy() {
        System.exit(0)
    }

    override fun exec(cmd: String?): String {
        return try {
            val p = ProcessBuilder("sh", "-c", cmd ?: "").redirectErrorStream(true).start()
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor()
            out
        } catch (e: Exception) {
            "ERR " + e
        }
    }
}
